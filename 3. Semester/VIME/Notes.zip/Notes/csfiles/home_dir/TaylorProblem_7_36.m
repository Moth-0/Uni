function TaylorProblem_7_36()
%===================================================================%
% Program to numerically solve the equation of motion of the spring %
% pendulum, Problem 7.36 in Classical Mechanics by John R. Taylor.  %
% - Nikolaj Ravn                                                    %
%===================================================================%

close all; clc;
    
	% Parameters
	g = 9.82;	% Gravitational acceleration
	m = 1;		% mass of pendulum bob
	k = 3;		% Spring constants
	l0 = 1;		% relaxed length of spring without mass of bob
	parameters = [g; m; k; l0];

	% Analytic constants
	l = l0 + m*g/k;			% Relaced length of spring including mass of bob
	omega_r = sqrt(k/m);	% Harmonic frequncy of r motion
	omega_phi = sqrt(g/l);	% Harmonic frequency of phi motion
    fprintf('Analytic constants: \nl = \t\t%.2f \nomega_r = \t%.2f \nomega_phi = \t%.2f \n',l,omega_r,omega_phi)
    
	% Initial conditions
	% Play around!
	t_start = 0;
	t_end = 10;
	dt = 0.05;
	time_interval = [t_start:dt:t_end];
	r0 = l*1.05;					% 5% stretch from equilibrium
	r_dot0 = 0;						
	phi0 = 0.1;
	phi_dot0 = 0;
	h0 = [r0; r_dot0; phi0; phi_dot0];

	% Solve differential equations
	opts = odeset('RelTol',1e-8);
	[t, h] = ode45(@(t,h) diffeq(t,h,parameters),time_interval,h0,opts);

	% Coordinates
	r = h(:,1);
	phi = h(:,3);
	x = r.*sin(phi);
	y = -r.*cos(phi);

	% To construct spring
	xs = 0.5*[0 0 0 0 0 1 0 -1 0 1 0 -1 0 1 0 0 0 0 0];
	ys = -linspace(0,1,length(xs));

	% Plot simulation in time
	figure()
		hold on
		axis equal
		axis([-2 2 -6 1])
		plot([-2 2],[0 0],'k-','LineWidth',1)				% Plot ceiling
		prettifyPlot();
		% Plot spring
		spring = plot(xs*cos(phi(1)) - r(1)*ys*sin(phi(1)), xs*sin(phi(1)) + r(1)*ys*cos(phi(1)),'k-','LineWidth',2);
		bob = plot(x(1),y(1),'.','MarkerSize',45);			% Pendulum bob
		for k = 1:length(t)
			% Update spring
			set(spring,'XData',xs*cos(phi(k)) - r(k)*ys*sin(phi(k)), 'YData', xs*sin(phi(k)) + r(k)*ys*cos(phi(k)));
			set(bob,'XData',x(k),'yData',y(k));				% Update bob
			pause(dt)										% Comment out to skip animation
		end

	% Fit harmonic oscillator to equation of motion
	harmonic = 'A*cos(w*x) + k';										% Fit to harmonic oscilation
	[fit_r, gof_r] = fit(t,r,harmonic,'Start',[0.2 l omega_r]);			% Fit equation of motion for r
	[fit_phi, gof_phi] = fit(t,phi,harmonic,'Start',[0.1 0 omega_phi]);	% Fit equation of motion for phi
	r_params = coeffvalues(fit_r);
	phi_params = coeffvalues(fit_phi);
    fprintf('Fitting parameters: \nl = \t\t%.2f \nomega_r = \t%.2f \nomega_phi = \t%.2f \n',r_params(2),r_params(3),phi_params(3))
    
	% Plot solutions
	figure()
		subplot(2,1,1)      % Plot data for r motion
			hold on
            plot([t(1) t(end)], [l l], 'k--','LineWidth',1.5)   % plot relaxed length of spring
			plot(t,r,'b','LineWidth',1.5)
			plot(t,r_params(1)*cos(r_params(3)*t) + r_params(2),'r','LineWidth',1.5)
			xlabel('[time]','FontSize',14,'Interpreter','Latex')
			ylabel('r','FontSize',14,'Interpreter','Latex')
			legend('l','eom','fit')
			prettifyPlot()
		subplot(2,1,2)      % Plot data for phi motion
			hold on
			plot(t,phi,'b','LineWidth',1.5)
			plot(t,phi_params(1)*cos(phi_params(3)*t) + phi_params(2),'r','LineWidth',1.5)
			xlabel('[time]','FontSize',14,'Interpreter','Latex')
			ylabel('$\phi$','FontSize',14,'Interpreter','Latex')
			legend('eom','fit')
			prettifyPlot()
end

%% =========== %%
%   Functions   %
%  ===========  %
%% Equation of motion
function dhdt = diffeq(t,h,params)
	% Use proper naming
	r = h(1);
	r_dot = h(2);
	phi = h(3);
	phi_dot = h(4);

	% Parameters
	g = params(1);
	m = params(2);
	k = params(3);
	l0 = params(4);

	% Differential equations
	drdt = r_dot;
	dr_dotdt = r*phi_dot^2 + g*cos(phi) - k/m*(r - l0);
	dphidt = phi_dot;
	dphi_dotdt = -2*r_dot/r*phi_dot - g/r*sin(phi);

	dhdt = [drdt; dr_dotdt; dphidt; dphi_dotdt];
end

%% Makes a plot look better
function prettifyPlot()
	ax = gca;
	set(ax,'TickLabelInterpreter','latex' )
	set(ax,'XMinorTick','on','YMinorTick','on')
	set(ax,'XMinorTick','on','YMinorTick','on')
	set(ax,'ticklength',2*[0.0100    0.0250])
	set(ax,'Layer','top')
end
