function KapitzaPendulum()
%====================================================================%
% Program to plot the effective potential of the Kapitza pendulum    %
% - Nikolaj Ravn                                                     %
%====================================================================%

close all; clear all; clc;

	% Parameters
	g = 9.82;
	m = 1;
	l = 1;
	a = 0.1*l;
	omega0 = sqrt(g/l);
	nu = 10*omega0;

	% Constant c = 1/2 * (a/l)^2 * (nu/omega0)^2 = 1/2 * a^2 * nu^2 / (g * l)
	c = 1/2*(a/l)^2*(nu/omega0)^2;


	% Effective potential
	V_eff = @(x,c) - omega0^2*m*l^2*( cos(x) - 1/2*c*sin(x).^2);


	V_pendulum = @(x) -omega0^2*m*l^2*cos(x);
	V_driving = @(x,c) omega0^2*m*l^2*1/2*c*sin(x).^2;


	phi0 = linspace(-2*pi,2*pi,100);



	figure()
		prettifyPlot
		hold on
		axis([-2*pi 2*pi -2 3])
		h1 = plot(phi0,V_eff(phi0,c)/(omega0^2*m*l^2),'LineWidth',1.5);
		h2 = plot(phi0,V_pendulum(phi0)/(omega0^2*m*l^2),'--','LineWidth',1.5);
		h3 = plot(phi0,V_driving(phi0,c)/(omega0^2*m*l^2),'-.','LineWidth',1.5);
		str = ['$\frac{1}{2} \Big( \frac{a}{l} \Big)^2 \Big( \frac{\nu}{\omega_0} \Big)^2 = $',num2str(c)];
		h4 = text(-pi,2.5,str);
		xticks([-2*pi -pi 0 pi 2*pi])
		xticklabels({'$-2\pi$','$-\pi$','0','$\pi$','$2\pi$'})
		xlabel('$\phi_0$')
		ylabel('$V/ ml^2\omega_0^2$')
		legend('$V_{eff}$','$V_{pend}$','$V_{drive}$')
	
		pause(5)
		for c = 0.5:0.01:3
			set(h1,'XData',phi0,'YData',V_eff(phi0,c)/(omega0^2*m*l^2));
			set(h3,'XData',phi0,'YData',V_driving(phi0,c)/(omega0^2*m*l^2));
			if mod(c*10,1) == 0
				str = ['$\frac{1}{2} \Big( \frac{a}{l} \Big)^2 \Big( \frac{\nu}{\omega_0} \Big)^2 = $',num2str(c)];
				set(h4,'String',str);
			end
			if c == 1
				text(-1.5*pi, -1.2,'Stable equilibrium')
				plot([-pi -pi],[0.5 0.9],'k-','LineWidth',1.5)
				plot(-pi,0.9,'^','MarkerFaceColor','k','MarkerEdgeColor','k')
				plot([pi pi],[0.5 0.9],'k-','LineWidth',1.5)
				plot(pi,0.9,'^','MarkerFaceColor','k','MarkerEdgeColor','k')
				pause(5)			
			end
			pause(0.05)
		end

end

% Makes a plot look better
function prettifyPlot()
	set(0,'defaultTextInterpreter', 'latex');
	set(0,'defaultTextFontSize', 14)
	set(0,'defaultAxesFontSize', 14)
	set(0,'defaultLegendInterpreter','latex')

	ax = gca;
	set(ax,'TickLabelInterpreter','latex' )
	set(ax,'XMinorTick','on','YMinorTick','on','ZMinorTick','on')
	set(ax,'ticklength',2*[0.0100    0.0250])
	set(ax,'Layer','top')
end